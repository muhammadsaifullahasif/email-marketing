# VDOM

Experimental module for transition from "contentedatable" to work with vdom

> Until the announcement, you should not use its functionality
