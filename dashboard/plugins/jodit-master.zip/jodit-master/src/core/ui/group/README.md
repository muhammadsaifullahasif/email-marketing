Group component
