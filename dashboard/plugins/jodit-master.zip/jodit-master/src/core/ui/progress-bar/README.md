# Jodit Progress Bar UI element
