Module for working with tables . Delete, insert , merger, division of cells , rows and columns.
When creating elements such as `<table>` for each of them
creates a new instance Jodit.modules.Table and it can be accessed via $('table').data('table-processor')
