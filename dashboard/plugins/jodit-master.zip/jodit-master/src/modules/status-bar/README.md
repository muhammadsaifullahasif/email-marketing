Status bar module
