Jodit Tab widget
