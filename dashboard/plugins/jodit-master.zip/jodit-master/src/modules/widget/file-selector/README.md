Jodit File Selector widgets
