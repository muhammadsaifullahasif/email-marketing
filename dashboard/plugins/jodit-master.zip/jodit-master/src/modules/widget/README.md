Jodit widgets
