Jodit Color Picker widgets
