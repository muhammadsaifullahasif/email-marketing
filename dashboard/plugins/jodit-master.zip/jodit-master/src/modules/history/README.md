To clear the history, you can call the method:

```js
editor.history.clear();
```
