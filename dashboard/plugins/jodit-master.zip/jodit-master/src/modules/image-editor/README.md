# Image editor module

Photo editing is configured through the interface [[ImageEditorOptions]]

for example:

```js
Jodit.make('#editor', {
	imageeditor: {
		crop: false,
		resize: true
	}
});
```
