# About Jodit

Plugin adds button with question icon and show dialog with Jodit's version and some information.
