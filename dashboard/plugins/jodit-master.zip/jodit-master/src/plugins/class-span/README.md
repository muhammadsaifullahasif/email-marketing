# Button with class selector

Plugins adds button with class list. When clicked, this class is applied to the selected text.
