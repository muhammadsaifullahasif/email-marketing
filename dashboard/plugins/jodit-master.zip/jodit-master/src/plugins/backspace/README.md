# Backspace/Delete correct behavior

Correctly handles the behavior of the Backspace and Delete keys
